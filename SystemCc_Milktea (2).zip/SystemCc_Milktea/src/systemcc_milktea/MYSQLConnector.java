
package systemcc_milktea;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MYSQLConnector {
  public Connection getConnection()
    {
        Connection con;
        try {
               String myDriver = "org.gjt.mm.mysql.Driver";
               String myUrl = "jdbc:mysql://localhost/milktea";
               Class.forName(myDriver);
               con = (Connection) DriverManager.getConnection(myUrl, "root", "");
               return con;
        }
        catch(Exception e){
            e.printStackTrace();
            return null;
        } 
    }

     public void executeSQLQuery(String query,String message)
    {
        Connection con=getConnection();
        Statement st;
        try {
            st= (Statement) con.createStatement();
            if((st.executeUpdate(query))==1)
            {

            }
            else {
             //   JOptionPane.showMessageDialog(null, "Data Not" + message);
            }
        } catch(Exception ex){
            ex.printStackTrace();

        }
    }  
}
